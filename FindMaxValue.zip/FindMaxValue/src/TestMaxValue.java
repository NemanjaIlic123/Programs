public class TestMaxValue{
    public static void main(String[] args){
        MaxValue maxValue = new MaxValue();
        maxValue.findMaxValue();
    }
}