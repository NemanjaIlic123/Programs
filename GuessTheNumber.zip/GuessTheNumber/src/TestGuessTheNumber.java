class TestGuessTheNumber{
    public static void main(String[] args){
        GuessTheNumber guessTheNumber = new GuessTheNumber();
        guessTheNumber.guess();
    }
}