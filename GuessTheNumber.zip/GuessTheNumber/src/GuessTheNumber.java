import java.util.Scanner;

public class GuessTheNumber{
    void guess(){
        int numberImagined;
        int numberTried;
        boolean bingo;
        Scanner scanner = new Scanner(System.in);

        numberImagined = (int)(100 * Math.random()) + 1;
        bingo = false;

        System.out.println("I have imagined an integer 1 - 100");
        System.out.println("Try to guess the number");

        while(!bingo){
            System.out.print("Guess the number: ");
            numberTried = scanner.nextInt();

            if(numberImagined < numberTried)
                System.out.println("I have imagined smaller number.");
            else if(numberImagined > numberTried)
                System.out.println("I have imagined greater number.");
            else{
                System.out.println("BINGO! CONGRATULATIONS!");
                bingo = true;
            }
        }
    }
}