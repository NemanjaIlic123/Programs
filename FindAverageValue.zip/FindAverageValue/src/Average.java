import java.util.Scanner;

public class Average{
    private final Scanner scanner = new Scanner(System.in);

    double[] array;
    int numberOfElements;
    double sum;

    public void setArray(double[] array){
        this.array = array;
    }

    public void readValues(){
        System.out.print("Input number of elements: ");
        numberOfElements = scanner.nextInt();
        setArray(new double[numberOfElements]);

        System.out.println("Use \',\' for comma!");
        for(int i = 0; i < numberOfElements; i++){
            System.out.println("Input " + (i + 1) + ". number: ");
            array[i] = scanner.nextDouble();
        }
    }

    public void findAverage(){
        readValues();
        for(int i = 0; i< array.length; i++){
            sum += array[i];
        }

        double average = sum / numberOfElements;

        System.out.println("Sum of the elements: " + sum);
        System.out.println("Average value is: " + average);
    }
}