public class TestAverage{
    public static void main(String[] args){
        Average average = new Average();
        average.findAverage();
    }
}