import java.util.Scanner;

class ASCIIValue {
    public static void main(String[] args){
        var s = new Scanner(System.in);

        System.out.print("Input a character: ");

        char input = s.next().charAt(0);

        System.out.println("ASCII value of the character is: " + (int)input);
    }
}