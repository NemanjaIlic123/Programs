public class Main {
    public static void main(String[] args){
        LengthRecursion lengthRecursion = new LengthRecursion();

        int lengthOfTheString = lengthRecursion.stringLengthRecursiveMethod("This is an example.");

        System.out.println("Length of the string is: " + lengthOfTheString);
    }
}