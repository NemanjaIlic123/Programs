class LengthRecursion{
    int stringLengthRecursiveMethod(String str) {
        if (str.equals("")) return 0;

        return stringLengthRecursiveMethod(
                str.substring(1)) + 1;
    }
}