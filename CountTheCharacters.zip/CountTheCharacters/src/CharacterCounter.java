import java.util.Scanner;

public class CharacterCounter{
    void count(String input){
        char[] ch = input.toCharArray();

        int letters = 0; // count letters
        int spaces = 0; // count spaces
        int digits = 0; // count digits
        int other = 0; // count other

        for(int i = 0; i < input.length(); i++){
            if(Character.isLetter(ch[i]))
                letters++;

            else if(Character.isSpaceChar(ch[i]))
                spaces++;

            else if(Character.isDigit(ch[i]))
                digits++;

            else other++;
        }

        System.out.println("The sentence you passed as an argument is: " + input);
        System.out.println("Letters: " + letters);
        System.out.println("Digits: " + digits);
        System.out.println("Spaces: " + spaces);
        System.out.println("Other: " + other);
    }
}