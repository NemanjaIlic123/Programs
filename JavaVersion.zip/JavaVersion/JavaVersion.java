public class JavaVersion{
	public static void main(String[] args){
		Info info = new Info();
		info.printInfo();
	}
}