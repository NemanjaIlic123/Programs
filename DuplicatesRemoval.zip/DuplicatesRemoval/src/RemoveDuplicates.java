import java.util.Arrays; // used to print originalArray

//we will use byte types, since all values are in range from -128 to +127
class RemoveDuplicates{

    byte[] originalArray = {2, 2, 2, 4, 5, 12, 12, 99, 18, 99, 18, 33, 27, 56, 15};
    byte[] newArray = new byte[originalArray.length];

    byte indexOfNewArray = 0;

    void printOriginalArray(){
        System.out.println("Original array: " + Arrays.toString(originalArray));
    }

    void remove(){
        for(byte i = 0; i < originalArray.length; i++){
            byte duplicates = 0; // a simple flag for duplicates

            for(byte j = 0; j < i; j++){ // we must have another initializer in order to perform comparison
                if(originalArray[i] == originalArray[j]){
                    duplicates = 1; // change value of flag in case there are duplicates
                    break; // break inner loop and increase the initializer of outer loop
                }
            }

            // in case flag is unchanged, which means there are no duplicates, do the following
            if(duplicates == 0){
                newArray[indexOfNewArray] = originalArray[i]; // assign the value to the newArray
                indexOfNewArray++;
            }
        }
    }

    void printNewArray(){
        System.out.print("New array: [");

        for(byte i = 0; i < indexOfNewArray; i++)
            System.out.print(newArray[i] + ", ");

        System.out.print("\b\b]");
    }
}