public class TestRemoveDuplicates {
    public static void main(String[] args){
        RemoveDuplicates removeDuplicates = new RemoveDuplicates();
        removeDuplicates.printOriginalArray();
        removeDuplicates.remove();
        removeDuplicates.printNewArray();
    }
}