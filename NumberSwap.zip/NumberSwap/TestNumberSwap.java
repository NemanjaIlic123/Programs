public class TestNumberSwap {
	
	public static void main(String[] args){
		
		int a = 10;
		int b = 12;

		NumberSwap numberSwap = new NumberSwap();

		System.out.println("Using variables:");
		System.out.println("Before swap a = " + a + ", b = " + b);
		numberSwap.swap(a, b);
		System.out.println("After swap a = " + a + ", b = " + b);
		
		Numbers numbers = new Numbers();
		numbers.a = 44;
		numbers.b = 100;
		
		System.out.println();

		System.out.println("Using objects:");
		System.out.println("Before swap a = " + numbers.a + ", b = " + numbers.b);
		numberSwap.swap(numbers);
		System.out.println("After swap a = " + numbers.a + ", b = " + numbers.b);
	}
}