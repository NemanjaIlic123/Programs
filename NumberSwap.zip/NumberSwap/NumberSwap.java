class NumberSwap{
    
    void swap(int a, int b){
        
        int temp = a;
        a = b;
        b = temp;
    }
    
    void swap(Numbers numbers){

        int temp = numbers.a;
        numbers.a = numbers.b;
        numbers.b = temp;
    }
}