class Numbers {
    
    int a;
    int b;
}