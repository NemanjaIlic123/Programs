class Orientation{
    static int orientation(Point p, Point q, Point r){
        int value = (q.y - p.y) * (r.x - q.x) -
                (r.y - q.y) * (q.x - p.x);

        if(value == 0) return 0;

        return (value < 0) ? 1 : 2;
    }
}