class OnSegment{
    static boolean isOnSegment(Point p, Point q, Point r){
        if(q.x <= Math.max(p.x, r.x) &&
                q.x >= Math.min(p.x, r.x) &&
                q.y <= Math.max(p.y, r.y) &&
                q.y >= Math.min(p.y, r.y)) return true;

        return false;
    }
}