class ResultPrinter{

    static void printResult(){
        boolean result = Inside.isInside();

        System.out.println();
        if(result) System.out.println("The point IS inside the polygon");
        else System.out.println("The point IS NOT inside the polygon");
        System.out.println();
        System.out.println();
    }
}