class IntersectionCheck {
    static boolean doIntersect(Point p1, Point q1, Point p2, Point q2){
        int o1 = Orientation.orientation(p1, q1, p2);
        int o2 = Orientation.orientation(p1, q1, q2);
        int o3 = Orientation.orientation(p2, q2, p1);
        int o4 = Orientation.orientation(p2, q2, q1);

        if( (o1 != o2) && (o3 != o4) ) return true;

        if(o1 == 0 && OnSegment.isOnSegment(p1, p2, q1) ) return true;
        if(o2 == 0 && OnSegment.isOnSegment(p1, q2, q1) ) return true;
        if(o3 == 0 && OnSegment.isOnSegment(p2, p1, q2) ) return true;
        if(o4 == 0 && OnSegment.isOnSegment(p2, q1, q2) ) return true;

        return false;

    }
}