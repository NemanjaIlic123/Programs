import java.util.Scanner;

class Inside{
    private static Scanner scanner = new Scanner(System.in);
    static final int INF = 10_000;

    static boolean isInside(){

        int numberOfPolygonPoints = 0;

        System.out.print("Input number of polygon points: ");
        numberOfPolygonPoints = scanner.nextInt();

        while(numberOfPolygonPoints < 3){
            System.out.println("Number of polygon points must be at least 3.");
            System.out.print("Input number of polygon points again: ");
            numberOfPolygonPoints = scanner.nextInt();
        }

        Point polygon[] = new Point[numberOfPolygonPoints];

        int index = 0;

        do{

            System.out.println();
            System.out.print("Input x coordinate of the " + (index + 1) + ". polygon point: ");
            int firstCoordinate = scanner.nextInt();

            System.out.print("Input y coordinate of the " + (index + 1) + ". polygon point: ");
            int secondCoordinate = scanner.nextInt();

            polygon[index] = new Point(firstCoordinate, secondCoordinate);
            index++;
        } while(index < numberOfPolygonPoints);

        System.out.println();
        System.out.print("Input x coordinate of the random point: ");
        int xCoordinate = scanner.nextInt();

        System.out.print("Input y coordinate of the random point: ");
        int yCoordinate = scanner.nextInt();

        Point randomPoint = new Point(xCoordinate, yCoordinate);
        Point extreme = new Point(INF, randomPoint.y);

        int intersectionCounter = 0;
        int polygonPoint = 0;

        do{
            int nextPoint = (polygonPoint + 1) % numberOfPolygonPoints;

            if(IntersectionCheck.doIntersect(polygon[polygonPoint], polygon[nextPoint],
                    randomPoint, extreme))
            {

                if(Orientation.orientation(polygon[polygonPoint], randomPoint,
                        polygon[nextPoint]) == 0)
                    return OnSegment.isOnSegment(polygon[polygonPoint], randomPoint,
                            polygon[nextPoint]);

                intersectionCounter++;
            }

            polygonPoint = nextPoint;

        } while(polygonPoint != 0);

        return (intersectionCounter % 2 == 1);
    }
}