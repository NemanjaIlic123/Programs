import javax.swing.*;

public class JavaCalculator{

    private double total1;
    private double total2;
    private char mathOperator;

    private JPanel JavaCalculator;
    private JTextField textDisplay;
    private JButton buttonMultiply;
    private JButton buttonTwo;
    private JButton buttonThree;
    private JButton buttonFive;
    private JButton buttonEight;
    private JButton buttonZero;
    private JButton buttonPlus;
    private JButton buttonSix;
    private JButton buttonNine;
    private JButton buttonClear;
    private JButton buttonMinus;
    private JButton buttonDivide;
    private JButton buttonEquals;
    private JButton buttonOne;
    private JButton buttonFour;
    private JButton buttonSeven;
    private JButton buttonPoint;

    private void getOperator(String buttonText){
        mathOperator = buttonText.charAt(0);
        total1 += Double.parseDouble(textDisplay.getText());
        textDisplay.setText("");
    }

    public JavaCalculator() {
        buttonOne.addActionListener(e -> {
            String buttonOneText = textDisplay.getText() + buttonOne.getText();
            textDisplay.setText(buttonOneText);
        });

        buttonTwo.addActionListener(e -> {
            String buttonTwoText = textDisplay.getText() + buttonTwo.getText();
            textDisplay.setText(buttonTwoText);
        });

        buttonThree.addActionListener(e -> {
            String buttonThreeText = textDisplay.getText() + buttonThree.getText();
            textDisplay.setText(buttonThreeText);
        });

        buttonFour.addActionListener(e -> {
            String buttonFourText = textDisplay.getText() + buttonFour.getText();
            textDisplay.setText(buttonFourText);
        });

        buttonFive.addActionListener(e -> {
            String buttonFiveText = textDisplay.getText() + buttonFive.getText();
            textDisplay.setText(buttonFiveText);
        });

        buttonSix.addActionListener(e -> {
            String buttonSixText = textDisplay.getText() + buttonSix.getText();
            textDisplay.setText(buttonSixText);
        });

        buttonSeven.addActionListener(e -> {
            String buttonSevenText = textDisplay.getText() + buttonSeven.getText();
            textDisplay.setText(buttonSevenText);
        });

        buttonEight.addActionListener(e -> {
            String buttonEightText = textDisplay.getText() + buttonEight.getText();
            textDisplay.setText(buttonEightText);
        });

        buttonNine.addActionListener(e -> {
            String buttonNineText = textDisplay.getText() + buttonNine.getText();
            textDisplay.setText(buttonNineText);
        });

        buttonZero.addActionListener(e -> {
            String buttonZeroText = textDisplay.getText() + buttonZero.getText();
            textDisplay.setText(buttonZeroText);
        });

        buttonPlus.addActionListener(e -> {
            String buttonText = buttonPlus.getText();
            getOperator(buttonText);
        });

        buttonMinus.addActionListener(e -> {
            String buttonText = buttonMinus.getText();
            getOperator(buttonText);
        });

        buttonMultiply.addActionListener(e -> {
            String buttonText = buttonMultiply.getText();
            getOperator(buttonText);
        });

        buttonDivide.addActionListener(e -> {
            String buttonText = buttonDivide.getText();
            getOperator(buttonText);
        });

        buttonEquals.addActionListener(e -> {
            switch (mathOperator) {
                case '+' -> total2 = total1 + Double.parseDouble(textDisplay.getText());
                case '-' -> total2 = total1 - Double.parseDouble(textDisplay.getText());
                case '*' -> total2 = total1 * Double.parseDouble(textDisplay.getText());
                case '/' -> total2 = total1 / Double.parseDouble(textDisplay.getText());
            }

            textDisplay.setText(Double.toString(total2));
            total1 = 0.;
        });

        buttonClear.addActionListener(e -> {
            total2 = 0;
            textDisplay.setText("");
        });

        buttonPoint.addActionListener(e -> {
            if(textDisplay.getText().equals(""))
                textDisplay.setText("0.");

            else if(textDisplay.getText().contains("."))
                buttonPoint.setEnabled(false);

            else{
                String buttonPointText = textDisplay.getText() + buttonPoint.getText();
                textDisplay.setText(buttonPointText);
            }

            buttonPoint.setEnabled(true);
        });
    }

    public static void main(String[] args){
        JFrame frame = new JFrame("JavaCalculator");
        frame.setContentPane(new JavaCalculator().JavaCalculator);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}