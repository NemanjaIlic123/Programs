import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;

public class JavaCalculator{

    private double total1;
    private double total2;
    private char mathOperator;

    private JPanel JavaCalculator;
    private JTextField textDisplay;
    private JButton buttonMultiply;
    private JButton buttonTwo;
    private JButton buttonThree;
    private JButton buttonFive;
    private JButton buttonEight;
    private JButton buttonZero;
    private JButton buttonPlus;
    private JButton buttonSix;
    private JButton buttonNine;
    private JButton buttonClear;
    private JButton buttonMinus;
    private JButton buttonDivide;
    private JButton buttonEquals;
    private JButton buttonOne;
    private JButton buttonFour;
    private JButton buttonSeven;
    private JButton buttonPoint;

    private void getOperator(String buttonText){
        mathOperator = buttonText.charAt(0);
        total1 += Double.parseDouble(textDisplay.getText());
        textDisplay.setText("");
    }

    public JavaCalculator() {
        buttonOne.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonOneText = textDisplay.getText() + buttonOne.getText();
                textDisplay.setText(buttonOneText);
            }
        });

        buttonTwo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonTwoText = textDisplay.getText() + buttonTwo.getText();
                textDisplay.setText(buttonTwoText);
            }
        });

        buttonThree.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonThreeText = textDisplay.getText() + buttonThree.getText();
                textDisplay.setText(buttonThreeText);
            }
        });

        buttonFour.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonFourText = textDisplay.getText() + buttonFour.getText();
                textDisplay.setText(buttonFourText);
            }
        });

        buttonFive.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonFiveText = textDisplay.getText() + buttonFive.getText();
                textDisplay.setText(buttonFiveText);
            }
        });

        buttonSix.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonSixText = textDisplay.getText() + buttonSix.getText();
                textDisplay.setText(buttonSixText);
            }
        });

        buttonSeven.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonSevenText = textDisplay.getText() + buttonSeven.getText();
                textDisplay.setText(buttonSevenText);
            }
        });

        buttonEight.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonEightText = textDisplay.getText() + buttonEight.getText();
                textDisplay.setText(buttonEightText);
            }
        });

        buttonNine.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonNineText = textDisplay.getText() + buttonNine.getText();
                textDisplay.setText(buttonNineText);
            }
        });

        buttonZero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonZeroText = textDisplay.getText() + buttonZero.getText();
                textDisplay.setText(buttonZeroText);
            }
        });

        buttonPlus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonText = buttonPlus.getText();
                getOperator(buttonText);
            }
        });

        buttonMinus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonText = buttonMinus.getText();
                getOperator(buttonText);
            }
        });

        buttonMultiply.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonText = buttonMultiply.getText();
                getOperator(buttonText);
            }
        });

        buttonDivide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonText = buttonDivide.getText();
                getOperator(buttonText);
            }
        });

        buttonEquals.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (mathOperator){
                    case '+':
                        total2 = total1 + Double.parseDouble(textDisplay.getText());
                        break;

                    case '-':
                        total2 = total1 - Double.parseDouble(textDisplay.getText());
                        break;

                    case '*':
                        total2 = total1 * Double.parseDouble(textDisplay.getText());
                        break;

                    case '/':
                        total2 = total1 / Double.parseDouble(textDisplay.getText());
                        break;
                }

                textDisplay.setText(Double.toString(total2));
                total1 = 0.;
            }
        });

        buttonClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                total2 = 0;
                textDisplay.setText("");
            }
        });

        buttonPoint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textDisplay.getText().equals(""))
                    textDisplay.setText("0.");

                else if(textDisplay.getText().contains("."))
                    buttonPoint.setEnabled(false);

                else{
                    String buttonPointText = textDisplay.getText() + buttonPoint.getText();
                    textDisplay.setText(buttonPointText);
                }

                buttonPoint.setEnabled(true);
            }
        });
        buttonOne.addKeyListener(new KeyAdapter() {
        });
    }

    public static void main(String[] args){
        JFrame frame = new JFrame("JavaCalculator");
        frame.setContentPane(new JavaCalculator().JavaCalculator);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}