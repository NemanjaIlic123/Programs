import java.util.Scanner;

class StringReverse{
    void reverse(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input some sentence: ");
        char[] sentence = scanner.nextLine().toCharArray();

        System.out.println("Reversed string is: ");
        for(int i = sentence.length - 1; i >= 0; i--)
            System.out.print(sentence[i]);
    }
}