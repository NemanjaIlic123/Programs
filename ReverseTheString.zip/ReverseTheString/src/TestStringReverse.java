public class TestStringReverse{
    public static void main(String[] args){
        StringReverse stringReverse = new StringReverse();
        stringReverse.reverse();
    }
}