class TestArrayReverse{
    public static void main(String[] args){
        ArrayReverse arrayReverse = new ArrayReverse();
        int[] myArray1 = {2, 4, 15, 21};
        arrayReverse.reverse(myArray1);
    }
}