class TestElementsCounter{
	public static void main(String[] args){
		ElementsCounter elementsCounter = new ElementsCounter();
		int[] myArray = {2, 4, 56, 101, 1003, 23, 25, 24, 30, 16, 20};
		elementsCounter.count(myArray);
	}
}